# 문제접수 + 법률 에이전트 추가 가이드

이 버전은 기존 친구 코드의 **FastAPI + SQLAlchemy + SQLite** 방식을 그대로 사용합니다. Supabase는 필요하지 않습니다.

## 추가된 기능

### 1) 문제접수

- `POST /contracts/{contract_id}/issues`
  - 카테고리/상태 설명/사진 URL로 문제 접수
  - 같은 계약의 같은 카테고리 사전합의(`prior_agreements`)를 자동 조회
  - 사전합의가 있으면 `FOLLOW_AGREEMENT`, 없으면 `OPEN_CHAT` 반환
  - 채팅방에 `SYSTEM_ISSUE` 시스템 메시지 자동 생성
  - 기존 FCM 흐름을 통해 알림도 연동

- `GET /contracts/{contract_id}/issues`
  - 계약의 문제접수 목록 조회

- `GET /contracts/{contract_id}/issues/{issue_id}`
  - 문제접수 상세 조회

- `PATCH /contracts/{contract_id}/issues/{issue_id}/status`
  - 임대인이 처리 상태 변경

- `POST /contracts/{contract_id}/issues/{issue_id}/resolve`
  - 누가 해결했는지, 해결 방법, 비용, 부담주체, 결제상태, 영수증, 완료일 기록

### 2) 사진 업로드

- `POST /uploads/issues` — 문제 사진
- `POST /uploads/receipts` — 영수증 사진

업로드 결과의 `url`을 문제접수/해결 API body의 `photo_url`, `receipt_image_url`에 넣습니다.

예: `/uploads/issues/abc123.jpg`

### 3) 법률 에이전트

- `POST /contracts/{contract_id}/legal-advice`

자동으로 참고하는 정보:

- 현재 계약 정보
- 건물/동/호 정보
- 사전합의사항
- 해당 계약의 최근 문제접수 기록

사용자는 법률 도움 카테고리와 질문만 입력합니다.

카테고리:

- `RENT`
- `DEPOSIT`
- `REPAIR_COST`
- `CONTRACT`
- `DEFECT`
- `EVICTION`
- `ETC`

`ETC`일 때 `custom_category`에 직접 입력할 수 있습니다.

## 실행

```bash
cd backend
python -m venv .venv
```

Windows PowerShell:

```powershell
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

`.env.example`을 `.env`로 복사합니다.

```env
JWT_SECRET_KEY=change-me
DATABASE_URL=sqlite:///./app.db
OPENAI_API_KEY=여기에_API_키
OPENAI_MODEL=gpt-5.6-luna
```

실행:

```bash
uvicorn app.main:app --reload
```

Swagger:

`http://127.0.0.1:8000/docs`

## Swagger에서 문제접수 테스트 순서

1. `POST /auth/signup/landlord`
2. `POST /buildings`
3. `POST /buildings/{building_id}/units`
4. `POST /units/{unit_id}/contracts`
5. `POST /units/{unit_id}/contracts/{contract_id}/invite-code`
6. `POST /auth/signup/tenant`
7. `POST /auth/login`
8. Swagger 우측 상단 `Authorize`에 access token 입력
9. 필요하면 `POST /contracts/{contract_id}/agreements`로 사전합의 등록
10. `POST /contracts/{contract_id}/issues`로 문제접수
11. `GET /contracts/{contract_id}/messages`에서 시스템 메시지 자동 생성 확인
12. `POST /contracts/{contract_id}/issues/{issue_id}/resolve`로 해결 완료
13. `POST /contracts/{contract_id}/legal-advice`로 법률 질문

## 문제접수 예시

```json
{
  "category": "BOILER",
  "description": "온수가 나오지 않습니다.",
  "photo_url": null
}
```

사전합의가 없으면 응답의 `next_action`이 `OPEN_CHAT`이 되어 채팅 해결 흐름으로 보낼 수 있습니다.

## 해결 기록 예시

```json
{
  "resolver": "REPAIR_VENDOR",
  "resolved_detail": "보일러 순환펌프를 교체했습니다.",
  "cost": 80000,
  "payer": "LANDLORD",
  "payment_status": "PAID",
  "receipt_image_url": null,
  "completed_at": "2026-09-12T16:00:00"
}
```

`payer`는 `LANDLORD`, `TENANT`, `SHARED` 중 하나입니다.

## 법률 에이전트 예시

```json
{
  "category": "REPAIR_COST",
  "custom_category": null,
  "question": "보일러 수리비는 누가 부담해야 하나요?"
}
```

이 요청을 받으면 백엔드가 계약 정보 + 사전합의 + 문제접수 기록을 모아서 AI에 함께 보냅니다.

## 주의

기존에 `app.db`가 이미 만들어져 있고 `issue_reports` 테이블이 예전 구조라면 SQLAlchemy의 `create_all()`은 기존 컬럼을 자동 추가하지 않습니다. 해커톤 로컬 테스트 단계에서 기존 데이터가 중요하지 않다면 `app.db`를 삭제하고 서버를 다시 실행하는 게 가장 빠릅니다.
