from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from .database import Base, engine
from .routers import (
    agreements,
    auth,
    buildings,
    chat,
    contract_detail,
    contracts,
    dashboard,
    profile,
    push,
    repair_vendors,
    units,
    issues,
    legal,
)

Base.metadata.create_all(bind=engine)

app = FastAPI(title="NewbieThon API")

app.include_router(auth.router)
app.include_router(buildings.router)
app.include_router(units.router)
app.include_router(contracts.router)
app.include_router(contract_detail.router)
app.include_router(profile.router)
app.include_router(repair_vendors.router)
app.include_router(agreements.router)
app.include_router(dashboard.router)
app.include_router(chat.router)
app.include_router(push.router)
app.include_router(issues.upload_router)
app.include_router(issues.router)
app.include_router(legal.router)

# 로컬 이미지 업로드 파일을 프론트에서 볼 수 있게 정적 경로로 공개
app.mount("/uploads", StaticFiles(directory="uploads", check_dir=False), name="uploads")


@app.get("/health")
def health():
    return {"status": "ok"}
